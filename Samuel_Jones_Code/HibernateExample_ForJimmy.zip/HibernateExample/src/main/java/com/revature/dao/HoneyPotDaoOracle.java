package com.revature.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.revature.domains.HoneyPot;
import com.revature.util.SessionFactoryUtil;

public class HoneyPotDaoOracle implements HoneyPotDao {
	
	SessionFactory sf = SessionFactoryUtil.getSessionFactory();

	@Override
	public void updateHoneyPot(HoneyPot hp) {
		Session sess = sf.openSession();
		sess.update(hp);
		sess.close();
	}

	@Override
	public void insertHoneyPot(HoneyPot hp) {
		Session sess = sf.openSession();
		Transaction tx = sess.beginTransaction();
		sess.save(hp);
		tx.commit();
		sess.close();
		
	}

	@Override
	public void deleteHoneyPot(HoneyPot hp) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		s.delete(hp);
		s.close();

	}

	@Override
	public HoneyPot getHoneyPotById(int id) {
		Session sess = sf.openSession();
		Criteria crit = sess.createCriteria(HoneyPot.class).add(Restrictions.eq("honeyPotId", id));;
		HoneyPot hp = (HoneyPot)crit.uniqueResult();
		sess.close();
		return hp;
	}

	public List<HoneyPot> getAllHoneyPots() {
		Session sess = sf.openSession();
		Criteria crit = sess.createCriteria(HoneyPot.class);
		List<HoneyPot> result = crit.list();
		sess.close();
		return result;
	}
	
}
