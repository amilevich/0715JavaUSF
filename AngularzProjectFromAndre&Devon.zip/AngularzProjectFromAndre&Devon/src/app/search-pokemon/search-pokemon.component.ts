import { Component, OnInit } from '@angular/core';
import { PokemonService } from '../pokemon.service';

@Component({
  selector: 'app-search-pokemon',
  templateUrl: './search-pokemon.component.html',
  styleUrls: ['./search-pokemon.component.css']
})
export class SearchPokemonComponent implements OnInit {

  constructor(private _pokemonService: PokemonService) { }
 _pokemon = 'Search a pokemon here.';
  _searchTerm: string;
  data: any;

  set searchTerm(search: string){
    this._searchTerm = search;
  }

  get searchTerm(){
    return this._searchTerm;
  }

  onSearch(){
    this._pokemonService.searchPokemon(this._searchTerm).subscribe(data => {
      let boing = (data['pokemon']);
      this._pokemon = boing.name;
  })
  this._pokemonService.getPokemon(this._searchTerm).subscribe(data => {
    let boing = (data['pokemon']);
    let img = document.getElementById("pic");
      img.setAttribute("src",boing)
})
  }

  clickSearch(): void{
    this.onSearch();
  }

  ngOnInit() {
  }

}