package com.revature.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.revature.domains.Bear;
import com.revature.domains.HoneyPot;
import com.revature.util.SessionFactoryUtil;

public class BearDAOOracle implements BearDAO {
	
	SessionFactory sf = SessionFactoryUtil.getSessionFactory();
	
	@Override
	public void updateBear(Bear bear) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		s.saveOrUpdate(bear);
		s.close();
	}

	@Override
	public void insertBear(Bear bear) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		s.save(bear);
		s.close();
	}

	@Override
	public void deleteBear(Bear bear) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		s.delete(bear);
		s.close();
	}

	@Override
	public Bear selectBearById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public Bear selectBearById(int id) {
//		Session sess = sf.openSession();
//		Criteria crit = sess.createCriteria(Bear.class).add(Restrictions.eq("BEAR_ID", id));;
//		Bear bear = (Bear)crit.uniqueResult();
//		sess.close();
//		return hp;
//	}
	
}
