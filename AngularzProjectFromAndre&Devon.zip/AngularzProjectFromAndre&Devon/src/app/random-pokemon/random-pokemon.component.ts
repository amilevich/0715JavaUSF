import { Component, OnInit } from '@angular/core';
import { PokemonService } from '../pokemon.service';

@Component({
  selector: 'app-random-pokemon',
  templateUrl: './random-pokemon.component.html',
  styleUrls: ['./random-pokemon.component.css']
})
export class RandomPokemonComponent implements OnInit {
  _pokemon = 'Click the button to get a random Pokemon';

  constructor(private _pokemonService: PokemonService) { }

  ngOnInit() {
  }

  randomPokemonButtonClicked(){
    let pnum = 1+Math.floor(Math.random()*807)
    this._pokemonService.searchPokemon('' + pnum ).subscribe(data => {
      let boing  = (data['pokemon']);
      this._pokemon = boing.name;
    })
  }

}
