package com.revature.dao;

import com.revature.domains.Bear;

public interface BearDAO {
	public void updateBear(Bear bear);
	public void insertBear(Bear bear);
	public void deleteBear(Bear bear);
	public Bear selectBearById(int id);
	
}
