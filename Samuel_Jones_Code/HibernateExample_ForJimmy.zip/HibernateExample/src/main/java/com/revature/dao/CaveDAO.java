package com.revature.dao;

import com.revature.domains.Cave;

public interface CaveDAO {
	public void updateCave(Cave cave);
	public void insertCave(Cave cave);
	public void deleteCave(Cave cave);
	public Cave selectCaveById(int id);
	
}
