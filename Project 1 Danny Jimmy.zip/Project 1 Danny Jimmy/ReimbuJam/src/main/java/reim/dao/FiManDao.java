package reim.dao;

import model.FinanceManager;

public interface FiManDao {

	public FinanceManager CheckPassword(String name);
}
