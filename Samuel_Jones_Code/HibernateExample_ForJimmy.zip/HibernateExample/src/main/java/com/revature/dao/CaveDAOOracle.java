package com.revature.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.revature.domains.Cave;
import com.revature.util.SessionFactoryUtil;

public class CaveDAOOracle implements CaveDAO {
	SessionFactory sf = SessionFactoryUtil.getSessionFactory();
	
	@Override
	public void updateCave(Cave cave) {
		Session sess = sf.openSession();
		sess.update(cave);
		sess.close();
	}

	@Override
	public void insertCave(Cave cave) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		s.update(cave);
		s.close();
	}

	@Override
	public void deleteCave(Cave cave) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		s.delete(cave);
		s.close();
	}

	@Override
	public Cave selectCaveById(int id) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Criteria crit = s.createCriteria(Cave.class).add(Restrictions.eqOrIsNull("CAVE_ID", id));
		Cave cave = (Cave)crit.uniqueResult();
		s.close();
		return cave;
	}
}
