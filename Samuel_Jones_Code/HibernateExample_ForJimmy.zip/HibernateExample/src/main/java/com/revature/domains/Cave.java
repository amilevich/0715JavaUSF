package com.revature.domains;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CAVE")
public class Cave {
//	(CAVE_ID NUMBER(10),
//			CAVE_TYPE VARCHAR2(255 CHAR),
//			SQ_FOOTAGE FLOAT(126),
//			PRIMARY KEY(CAVE_ID)
//		);
	
	@Id
	@Column(name="CAVE_ID")
	@SequenceGenerator(name="AUTO_CAVE_ID", sequenceName="AUTO_CAVE_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AUTO_CAVE_ID")
	private int caveId;
	
	@Column(name="CAVE_TYPE")
	private String caveType;
	
	@Column(name="SQ_FOOTAGE")
	private double sqFootage;

	public int getCaveId() {
		return caveId;
	}

	public void setCaveId(int caveId) {
		this.caveId = caveId;
	}

	public String getCaveType() {
		return caveType;
	}

	public void setCaveType(String caveType) {
		this.caveType = caveType;
	}

	public double getSqFootage() {
		return sqFootage;
	}

	public void setSqFootage(double sqFootage) {
		this.sqFootage = sqFootage;
	}

	@Override
	public String toString() {
		return "Cave [caveId=" + caveId + ", caveType=" + caveType + ", sqFootage=" + sqFootage + "]";
	}

	public Cave(int caveId, String caveType, double sqFootage) {
		super();
		this.caveId = caveId;
		this.caveType = caveType;
		this.sqFootage = sqFootage;
	}
	public Cave() {
		// TODO Auto-generated constructor stub
	}
}
