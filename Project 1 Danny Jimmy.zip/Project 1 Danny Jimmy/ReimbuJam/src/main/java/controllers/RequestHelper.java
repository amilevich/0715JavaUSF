package controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RequestHelper {
	
	public static String process(HttpServletRequest request, HttpServletResponse response)
	{
		switch(request.getRequestURI())
		{
		case "/ReimbuJam/html/Login.jam":
			return LoginController.Login(request);
			
		case "/ReimbuJam/html/Request.jam":
			return EmpTestCont.RequestIt(request);
			
//		case "/ReimbursJam/html/RequestIt.jam":
//			return EmpReimReqController.RequestReim(request);
//			
//		case "/ReimbursJam/html/Login.do":
//			return LoginController.Login(request);
			default:
				return "/html/Login.html";
			
		}
	}

}
