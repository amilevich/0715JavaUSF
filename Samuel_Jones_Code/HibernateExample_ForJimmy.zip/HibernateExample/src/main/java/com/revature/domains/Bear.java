package com.revature.domains;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BEAR")
public class Bear {
//	(BEAR_ID NUMBER(10),
//			BEAR_COLOR VARCHAR2(255 CHAR),
//			BREED VARCHAR2(255 CHAR),
//			HEIGHT FLOAT(126),
//			WEIGHT FLOAT(126),
//			BEAR_HOME NUMBER(10),
//			HONEYPOT_ID NUMBER(10),
//			PRIMARY KEY(BEAR_ID),
//			FOREIGN KEY(BEAR_HOME) REFERENCES CAVE(CAVE_ID),
//			FOREIGN KEY(HONEYPOT_ID) REFERENCES HONEYPOT(HONEYPOT_ID)
//		);
	@Id
	@Column(name="BEAR_ID")
	@SequenceGenerator(name="AUTO_BEAR_ID", sequenceName="AUTO_BEAR_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator= "AUTO_BEAR_ID")
	private int bearId;
	
	@Column(name="BEAR_COLOR")
	private String bearColor;
	
	@Column(name="BREED")
	private String bearBreed;

	public int getBearId() {
		return bearId;
	}

	public void setBearId(int bearId) {
		this.bearId = bearId;
	}

	public String getBearColor() {
		return bearColor;
	}

	public void setBearColor(String bearColor) {
		this.bearColor = bearColor;
	}

	public String getBearBreed() {
		return bearBreed;
	}

	public void setBearBreed(String bearBreed) {
		this.bearBreed = bearBreed;
	}

	@Override
	public String toString() {
		return "Bear [bearId=" + bearId + ", bearColor=" + bearColor + ", bearBreed=" + bearBreed + "]";
	}

	public Bear(int bearId, String bearColor, String bearBreed) {
		super();
		this.bearId = bearId;
		this.bearColor = bearColor;
		this.bearBreed = bearBreed;
	}
	
	public Bear() {
		// TODO Auto-generated constructor stub
	}
	
	
}
