package controllers;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import model.Employee;

public class HomeController {

	public static String Home(HttpServletRequest request, HttpServletResponse response)
	{
		Employee emp = (Employee) request.getSession().getAttribute("Employee");
		
		try {
			//converting the object into JSON for JavaScript to receive
			response.getWriter().write(new ObjectMapper().writeValueAsString(emp));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	return null;
}
	
}
