import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WatComponent } from './wat.component';

describe('WatComponent', () => {
  let component: WatComponent;
  let fixture: ComponentFixture<WatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
