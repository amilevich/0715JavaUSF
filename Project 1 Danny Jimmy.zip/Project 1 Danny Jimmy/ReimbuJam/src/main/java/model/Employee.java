package model;

public class Employee {

	private int userID;
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	private int userRole;
	private int userRoleID;
	private int reiemID;
	private double reiemAmount;
	private String description;
	private String reiumDateTimeSub;
	private String reiumResolver;
	private int reimstatusID;
	private int reiemtypeID;

	protected Employee(int userID, String userName, String password, String firstName, String lastName, String email,
			int userRole, int userRoleID, int reiemID, int reiemAmount, String description, String reiumDateTimeSub,
			String ReiumResolver, int reimstatusID, int reiemtypeID) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.userRole = userRole;
		this.userRoleID = userRoleID;
		this.reiemID = reiemID;
		this.reiemAmount = reiemAmount;
		this.description = description;
		this.reiumDateTimeSub = reiumDateTimeSub;
		this.reiumResolver = reiumResolver;
		this.reimstatusID = reimstatusID;
		this.reiemtypeID = reiemtypeID;
	}


	public Employee() {
	}
	

	public String getReiumResolver() {
		return reiumResolver;
	}


	public void setReiumResolver(String ReiumResolver) {
		this.reiumResolver = ReiumResolver;
	}


	public int getReiemID() {
		return reiemID;
	}

	public void setReiemID(int reiemID) {
		this.reiemID = reiemID;
	}

	public double getReiemAmount() {
		return reiemAmount;
	}

	public void setReiemAmount(double amount) {
		this.reiemAmount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReiumDateTimeSub() {
		return reiumDateTimeSub;
	}

	public void setReiumDateTimeSub(String reiumDateTimeSub) {
		this.reiumDateTimeSub = reiumDateTimeSub;
	}

	public int getReimstatusID() {
		return reimstatusID;
	}

	public void setReimstatusID(int reimstatusID) {
		this.reimstatusID = reimstatusID;
	}

	public int getReiemtypeID() {
		return reiemtypeID;
	}

	public void setReiemtypeID(int reiemtypeID) {
		this.reiemtypeID = reiemtypeID;
	}

	public int getUserRoleID() {
		return userRoleID;
	}

	public void setUserRoleID(int userRoleID) {
		this.userRoleID = userRoleID;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getUserRole() {
		return userRole;
	}

	public void setUserRole(int userRole) {
		this.userRole = userRole;
	}

	@Override
	public String toString() {
		return "Employee [userID=" + userID + ", userName=" + userName + ", password=" + password + ", firstName="
				+ firstName + ", lastName=" + lastName + ", email=" + email + ", userRole=" + userRole + ", userRoleID="
				+ userRoleID + ", reiemID=" + reiemID + ", reiemAmount=" + reiemAmount + ", description=" + description
				+ ", reiumDateTimeSub=" + reiumDateTimeSub + ", ReiumResolver=" + reiumResolver + ", reimstatusID="
				+ reimstatusID + ", reiemtypeID=" + reiemtypeID + "]";
	}
	
}
