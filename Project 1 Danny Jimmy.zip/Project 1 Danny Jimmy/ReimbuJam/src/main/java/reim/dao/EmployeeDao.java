package reim.dao;

import model.Employee;

public interface EmployeeDao {

	public Employee CheckPassword(String name);

	boolean sendRequest(Employee reimRequest);

	boolean sendStatus();
}
