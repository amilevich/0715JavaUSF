package reim.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	static{

	       try {

	           Class.forName("oracle.jdbc.driver.OracleDriver");

	       } catch (ClassNotFoundException e) {

	           e.printStackTrace();

	       }

	   }

	private static String url = "jdbc:oracle:thin:@dbbcrevature.cr84lpfaefq1.us-east-2.rds.amazonaws.com:1521:orcl";
	private static String username ="admin119";
	private static String password ="passWord4";
	
	@Override
	public Employee CheckPassword(String userName) {
		
		Employee emp = new Employee();
		try (Connection conn = DriverManager.getConnection(url, username, password)) {

			PreparedStatement ps = conn.prepareStatement("SELECT * FROM ers_users WHERE ers_username=?");
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				emp.setUserID(rs.getInt(1));
				emp.setPassword(rs.getString(3));
				emp.setUserRoleID(rs.getInt(7));
				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return emp;
	}
	
	//insert into the ers_reimbursement Table for reeimbursement request
//	@Override
//	public boolean sendRequest(Employee reimRequest) {
//		try(
//				Connection conn = DriverManager.getConnection(url, username, password)){
//					PreparedStatement ps =  conn.prepareStatement("INSERT INTO ers_ers_reimbursement (reimid, reimAmount, reimSubDate, reimResolver, reimDescript, reimStatusID, reimTypeID, reimUserID) VALUES (?,?,?,?,?,?,?,?)");
//					ps.setInt(1, reimRequest.getReiemID());
//					ps.setDouble(2,reimRequest.getReiemAmount());					
//					ps.setString(3,reimRequest.getReiumDateTimeSub());
//					ps.setString(4,"pending resolver");
//					ps.setString(5, reimRequest.getDescription());
//					ps.setInt(6, 1);
//					ps.setInt(7, reimRequest.getReiemtypeID());
//					ps.setInt(8, reimRequest.getUserID());
//					
//					ps.executeUpdate();
//				}catch(Exception e){
//					//e.printStackTrace();
//					return false;
//				}
//		return true;
//	}
	//send employee request to database
	@Override
	public boolean sendRequest(Employee reimRequest) {
		try(
				Connection conn = DriverManager.getConnection(url, username, password)){
			PreparedStatement ps =  conn.prepareStatement("INSERT INTO ers_reium VALUES (?,?,?,?,?,?,?,?,?)");
			
					ps.setInt(1, 3);
					ps.setDouble(2, reimRequest.getReiemAmount());
					ps.setString(3, reimRequest.getReiumDateTimeSub());
					ps.setString(4, "pending");
					ps.setString(5, reimRequest.getDescription());
					ps.setString(6, "pending");
					ps.setInt(7, reimRequest.getReimstatusID());
					ps.setInt(8, reimRequest.getReiemtypeID());
					ps.setInt(9, reimRequest.getUserID());
							
					ps.executeUpdate();
				}catch(Exception e){
					e.printStackTrace();
					return false;
				}
		return true;
	}
	
	@Override
	public boolean sendStatus() {
		try(
				Connection conn = DriverManager.getConnection(url, username, password)){
			PreparedStatement ps =  conn.prepareStatement("INSERT INTO ers_reium_status VALUES(3, 'pending'");
					
					ps.executeUpdate();
				}catch(Exception e){
					e.printStackTrace();
					return false;
				}
		return true;
	}
	
}
