package controllers;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import model.Employee;
import reim.dao.EmployeeDaoImpl;

public class EmpReimReqController {

		public static String RequestReim(HttpServletRequest request) {
			Employee emp = (Employee) request.getSession().getAttribute("employee");
			double amount = Double.parseDouble((request.getParameter("amount")));
			int type = Integer.parseInt((request.getParameter("retype")));
			System.out.println("1");
			
			DateFormat df = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
			Date dateobj = new Date();
//			System.out.println(df.format(dateobj));
			System.out.println("2");
			
//			Employee emp = new Employee();
			emp.setReiemAmount(amount);
			emp.setReiemtypeID(type);
			emp.setReiumDateTimeSub(df.format(dateobj));
			emp.setUserID(emp.getUserID());			
			System.out.println("3");
			
			EmployeeDaoImpl empDaoImpl = new EmployeeDaoImpl();
//			petDaoImpl.insertPet(pet);
			if(empDaoImpl.sendRequest(emp))
			{
				return "/html/Employee.html";
			}
			else
			{
				System.out.println("broken");
			}
			
			return null;
	
		}
	}
