package com.revature.driver;

import java.util.List;

import org.hibernate.SessionFactory;

import com.revature.dao.HoneyPotDaoOracle;
import com.revature.domains.HoneyPot;
import com.revature.util.SessionFactoryUtil;

public class HibernateDriver {

	private static SessionFactory sf = SessionFactoryUtil.getSessionFactory();
	
	public static void main(String[] args) {
		HoneyPot hp = new HoneyPot(1,900,200);
		HoneyPotDaoOracle hpdi = new HoneyPotDaoOracle();
//		hpdi.insertHoneyPot(hp);
//		hpdi.updateHoneyPot(new HoneyPot(1,1.1,1.1));
//		hpdi.deleteHoneyPot(hp);
		
		List<HoneyPot> hpList = hpdi.getAllHoneyPots();
		System.out.println(hpList);
		
		HoneyPot newHp = hpdi.getHoneyPotById(200);
		System.out.println(newHp);
//		
//		Bear b = new Bear();
//		BearDAOOracle bdi = new BearDAOOracle();
//		bdi.insertBear(b);
//		
//		Cave c = new Cave();
//		CaveDAOOracle cdi = new CaveDAOOracle();
//		cdi.insertCave(c);
//		Session s = sf.openSession();
//		System.out.println("Working fine!");
//		s.close();
	}
	
}
