package controllers;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import model.Employee;
import model.FinanceManager;
import reim.dao.EmployeeDaoImpl;
import reim.dao.FiManDaoImpl;

public class LoginController {
	
	private static Logger log = Logger.getLogger(LoginController.class);
	
	public static String Login(HttpServletRequest request)
	{
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		EmployeeDaoImpl empDaoImpl = new EmployeeDaoImpl();
		FiManDaoImpl fiManDaoImpl = new FiManDaoImpl();
		Employee emp = new Employee();
		FinanceManager fiMan = new FinanceManager();
//		request.getSession().setAttribute("Employee", emp);
		emp = empDaoImpl.CheckPassword(username);
		fiMan = fiManDaoImpl.CheckPassword(username);
		
		if(password.equals(emp.getPassword()) && emp.getUserRoleID() == 1)
		{
			request.getSession().setAttribute("Employee", emp);
			log.info("Username: "+ username + "Logged in");
//			return "Employee.html";
			return "/html/EmpTest.html";
		}
		else if(password.equals(fiMan.getPassword()))
		{
			request.getSession().setAttribute("FinanceManager", fiMan);
			log.info("Username: "+ username + "Logged in");
			return "FinanceManager.html";
		}
		
		return "Login.html";
	}

}
