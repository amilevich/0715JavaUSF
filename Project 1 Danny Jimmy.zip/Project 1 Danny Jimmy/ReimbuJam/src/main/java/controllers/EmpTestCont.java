package controllers;

import java.time.LocalDate;

import javax.servlet.http.HttpServletRequest;

import model.Employee;
import oracle.sql.DATE;
import reim.dao.EmployeeDaoImpl;

public class EmpTestCont {
public static String RequestIt(HttpServletRequest request) {
//	Employee emp = (Employee) request.getSession().getAttribute("employee");
	
		int number = Integer.parseInt(request.getParameter("reimReq"));
//		int amunt = Integer.parseInt(request.getParameter("amountReq"));
		String description = request.getParameter("description");
		
		String date = "" + LocalDate.now();
		
		Employee employee = (Employee) request.getSession().getAttribute("Employee");
		System.out.println(employee);
		Employee emp = new Employee();
		emp.setReiemID(2);
		emp.setDescription(description);
		emp.setDescription(description);
		emp.setUserID(employee.getUserID());
		emp.setReiumDateTimeSub(date);
		emp.setReimstatusID(1);
		emp.setReiemtypeID(1);
		emp.setReiemAmount(number);
		
		
//		Pet pet = new Pet();
//		pet.setName(name);
//		pet.setType(type);
		
//		PetDaoImpl petDaoImpl = new PetDaoImpl();
//		petDaoImpl.insertPet(pet);
		System.out.println("good");
		EmployeeDaoImpl empDaoImpl = new EmployeeDaoImpl();
		System.out.println("Good");
		if(empDaoImpl.sendRequest(emp))
		{
			System.out.println("hhhh");
			return "/html/EmpTest.html";
		}
		else
		{
			System.out.println("broken");
		}
		
		return null;

	}
}

