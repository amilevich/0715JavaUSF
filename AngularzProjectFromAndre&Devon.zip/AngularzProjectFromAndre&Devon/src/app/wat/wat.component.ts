import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wat',
  templateUrl: './wat.component.html',
  styleUrls: ['./wat.component.css']
})
export class WatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
