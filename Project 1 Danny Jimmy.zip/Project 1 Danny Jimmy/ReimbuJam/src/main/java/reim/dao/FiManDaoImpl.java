package reim.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.FinanceManager;

public class FiManDaoImpl implements FiManDao {

	static{

	       try {

	           Class.forName("oracle.jdbc.driver.OracleDriver");

	       } catch (ClassNotFoundException e) {

	           e.printStackTrace();

	       }

	   }

	private static String url = "jdbc:oracle:thin:@dbbcrevature.cr84lpfaefq1.us-east-2.rds.amazonaws.com:1521:orcl";
	private static String username ="admin119";
	private static String password ="passWord4";
	
	@Override
	public FinanceManager CheckPassword(String userName) {
		
		FinanceManager fiMan = new FinanceManager();
		try (Connection conn = DriverManager.getConnection(url, username, password)) {

			PreparedStatement ps = conn.prepareStatement("SELECT * FROM ers_users WHERE ers_username=?");
			ps.setString(1, userName);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				fiMan.setPassword(rs.getString(3));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return fiMan;
	}

	//use this for getting the pending request info from the table since it grabs more info
//	public FinanceManager CheckPasswordSt(String userName)
//	{
//		FinanceManager fiMan = new FinanceManager();
//		try (Connection conn = DriverManager.getConnection(url, username, password))
//		{
//			Statement ps = conn.createStatement("SELECT * FROM ers_users WHERE ers_username=?");
//			ResultSet rs = .executeQuery();
//			while(rs.next())
//			{
//				fiMan.setPassword(rs.getString(3));
//			}
//		}
//	 catch (SQLException e) {
//		e.printStackTrace();
//	}
//		return fiMan;
//	}
	
}
